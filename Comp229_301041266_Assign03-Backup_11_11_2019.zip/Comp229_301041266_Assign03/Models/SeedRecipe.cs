﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace Comp229_301041266_Assign03.Models
{
    public static class SeedRecipe
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();

            context.Database.Migrate();

            if (!context.Recipes.Any())
            {
                context.Recipes.AddRange(
                    new Recipe
                    {
                        RecipeName = "Chocolate cake",
                        RecipeCategory = "Desserts",
                        RecipeNumberPortions = "8",
                        RecipeCookTime = "120",
                        RecipeIngredient = "all purpose flour,,granulated white sugar,," +
                "unsweetened cocoa powder,,baking soda,,salt,,large eggs,,buttermilk or substitute by putting 1 tbsp white vinegar" +
                "in a cup then filling the rest up with milk; let stand 5 minutes until thickened,,butter melted,,vanilla extract,,hot " +
                "coffee or 2 tsp instant coffee in 1 cup boiling water",
                        RecipeIngredientQty = "1 3/4,,2,,3/4,,1 1/2,,3/4,,2,,1,,1/2,,1,,1",
                        RecipeIngredientUnit = "cups,,cups,,cup,,tsp,,teaspoon,, ,,cup,,cup,,tbsp,,cup",
                        RecipeNarrative = "1 - Preheat oven to 350 degrees. " +
                "Grease and flour two 9-inch baking pans (or line with parchment paper circles) and set aside. 2 - In the large bowl of a " +
                "standing mixer, stir together flour, sugar, cocoa, baking soda, and salt. Add eggs, buttermilk, melted butter and vanilla " +
                "extract and beat until smooth (about 3 minutes). Remove bowl from mixer and stir in hot coffee with a rubber spatula. " +
                "Batter will be very runny. 3 - Pour batter evenly between the two pans and bake on middle rack of oven for about 35 minutes, " +
                "until toothpick inserted in centre comes out clean with just a few moist crumbs attached. 4 - Allow to cool 15 minutes in pans, " +
                "then run a butter knife around the edges of each cake. Place a wire cooling rack over top of each pan. Wearing oven mitts, " +
                "use both hands to hold the racks in place while flipping the cakes over onto the racks. Set the racks down and gently thump " +
                "on the bottom of the pans until the cakes release. Cool completely before handling or frosting."
                    },
            new Recipe
            {
                RecipeName = "Juicy Roasted Chicken",
                RecipeCategory = "Main Dishes",
                RecipeNumberPortions = "6",
                RecipeCookTime = "100",
                RecipeIngredient = "whole chicken, giblets removed,," +
                "salt and black pepper,,onion powder, or to taste,,margarine, divided,,stalk celery, leaves removed",
                RecipeIngredientQty = "3,, ,,1,,1/2,,1",
                RecipeIngredientUnit = "pound,,to taste,,tablespoon,,cup,,unit",
                RecipeNarrative = "1- Preheat oven to 350 degrees F (175 degrees C). 2- Place chicken in a roasting pan, " +
                "and season generously inside and out with salt and pepper. Sprinkle inside and out with onion powder. " +
                "Place 3 tablespoons margarine in the chicken cavity. Arrange dollops of the remaining margarine around the " +
                "chicken's exterior. Cut the celery into 3 or 4 pieces, and place in the chicken cavity. 3- Bake uncovered 1 hour " +
                "and 15 minutes in the preheated oven, to a minimum internal temperature of 180 degrees F(82 degrees C). Remove " +
                "from heat, and baste with melted margarine and drippings.Cover with aluminum foil, and allow to rest about 30 " +
                "minutes before serving."
            }
            );
                
                context.Reviews.AddRange(
                    new ReviewRecipe
                    {
                        RecipeNumber=1,
                        ReviewContent="Great recipe!"
                    },
                    new ReviewRecipe
                    {
                        RecipeNumber = 2,
                        ReviewContent = "Like this recipe!"
                    },
                    new ReviewRecipe
                    {
                        RecipeNumber = 1,
                        ReviewContent = "Didn´t like it."
                    }
                    );
                    
                context.SaveChanges();
            }
        }
    }
}
